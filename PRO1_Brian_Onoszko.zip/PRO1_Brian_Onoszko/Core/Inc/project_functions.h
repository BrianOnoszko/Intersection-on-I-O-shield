/**
 ****************************************************************
 @brief		project_functions, definition of functions for the main program tasks
 @file		project_functions.h
 @author	Brian Onoszko
 @version 	1.0
 @date		06-December-2023
 @brief		Function and variable definitions associated with project, makes variables extern to be used in both project_functions.c and in freertos.c
 ****************************************************************
 */

#ifndef INC_PROJECT_FUNCTIONS_H_
#define INC_PROJECT_FUNCTIONS_H_
#include <stdint.h>

extern uint8_t shift_reg_data[3];

extern uint8_t waiting_pl_north;
extern uint8_t waiting_pl_west;
extern uint8_t interrupt_pl_north;
extern uint8_t interrupt_pl_west;
extern uint8_t waiting_tl_vertical;
extern uint8_t waiting_tl_horizontal;
extern uint8_t status_tl_vertical;
extern uint8_t status_tl_horizontal;
extern uint8_t status_pl_north;
extern uint8_t status_pl_west;
extern uint8_t greenMax;
extern uint32_t greenDelay;
extern uint32_t orangeDelay;
extern uint32_t redDelayMax;
extern uint32_t toggleFreq;
extern uint32_t walkingDelay;
extern uint32_t pedestrianDelay;

extern int test_var;

void write_to_SPI();
void clear_tl_vertical();
void clear_tl_horizontal();
void change_pl_north();
void change_pl_west();
void change_tl_horizontal();
void change_tl_vertical();
void toggle_pl_north();
void toggle_pl_west();


#endif /* INC_PROJECT_FUNCTIONS_H_ */
