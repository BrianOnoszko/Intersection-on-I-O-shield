/**
******************************************************
@brief		test, header file associated with test functions for test-Program
@file 		test.h
@author		Brian Onoszko
@version	1.0
@date		6-December-2023
@brief		Function definitions made for or
			associated with testing
******************************************************
 */

#ifndef INC_TEST_H_
#define INC_TEST_H_

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
//#define RUN_TEST_PROGRAM		//Uncomment to enable, comment to disable
/* USER CODE END PD */

/* USER CODE BEGIN 0 */

void Test_program(void);
void Test_Led_SPI(void);
void Test_Switches(void);
void Test_Interrupt(void);


/* USER CODE END 0 */


#endif /* INC_TEST_H_ */
